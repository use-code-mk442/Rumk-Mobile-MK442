package com.mk442.rumk;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int DARK_BG = Color.rgb(8, 7, 15);
    private static final int TOOLBAR_BG = Color.rgb(20, 17, 34);
    private static final int ACCENT = Color.rgb(190, 105, 255);

    private WebView webView;
    private WebViewAssetLoader assetLoader;
    private FrameLayout rootLayout;

    // Separate, unbridged WebView used for provider search and video pages.
    // This keeps external sites inside Rumk without exposing the native JS bridge to them.
    private WebView inAppBrowser;
    private View inAppBrowserPanel;
    private TextView inAppBrowserTitle;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(DARK_BG);
        getWindow().setNavigationBarColor(DARK_BG);
        getWindow().getDecorView().setSystemUiVisibility(0);

        rootLayout = new FrameLayout(this);
        rootLayout.setBackgroundColor(DARK_BG);

        webView = new WebView(this);
        webView.setBackgroundColor(DARK_BG);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);

        WebView.setWebContentsDebuggingEnabled(false);
        android.webkit.WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setUserAgentString(settings.getUserAgentString() + " RumkMK442/1.0");

        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        webView.addJavascriptInterface(new RumkBridge(), "RumkNative");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                android.webkit.WebResourceResponse response = assetLoader.shouldInterceptRequest(request.getUrl());
                return response != null ? response : super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
                if (isRumkAssetUrl(uri) || "about".equals(scheme)) return false;

                if (("https".equals(scheme) || "http".equals(scheme)) && request.isForMainFrame()) {
                    openInAppBrowser(uri.toString());
                    return true;
                }
                if ("https".equals(scheme) || "http".equals(scheme)) return false;

                Toast.makeText(MainActivity.this, "هذا الرابط غير مدعوم داخل Rumk", Toast.LENGTH_SHORT).show();
                return true;
            }
        });

        rootLayout.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(rootLayout);
        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html");
    }

    private boolean isRumkAssetUrl(Uri uri) {
        return "https".equalsIgnoreCase(uri.getScheme())
                && "appassets.androidplatform.net".equalsIgnoreCase(uri.getHost())
                && uri.getPath() != null
                && uri.getPath().startsWith("/assets/");
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private TextView toolbarButton(String label) {
        TextView button = new TextView(this);
        button.setText(label);
        button.setTextColor(Color.WHITE);
        button.setTextSize(15);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(10), 0, dp(10), 0);
        button.setBackgroundColor(Color.TRANSPARENT);
        button.setClickable(true);
        button.setFocusable(true);
        return button;
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void openInAppBrowser(String rawUrl) {
        if (rawUrl == null || rawUrl.length() > 4096) return;
        final Uri uri;
        try {
            uri = Uri.parse(rawUrl);
        } catch (Exception ex) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "الرابط غير صالح", Toast.LENGTH_SHORT).show());
            return;
        }
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
        if ((!"https".equals(scheme) && !"http".equals(scheme)) || uri.getHost() == null) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "افتح رابطًا يبدأ بـ https:// أو http://", Toast.LENGTH_SHORT).show());
            return;
        }
        runOnUiThread(() -> showInAppBrowser(uri));
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void showInAppBrowser(Uri uri) {
        if (rootLayout == null) return;
        if (inAppBrowserPanel == null) {
            LinearLayout panel = new LinearLayout(this);
            panel.setOrientation(LinearLayout.VERTICAL);
            panel.setBackgroundColor(DARK_BG);
            panel.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

            LinearLayout toolbar = new LinearLayout(this);
            toolbar.setOrientation(LinearLayout.HORIZONTAL);
            toolbar.setGravity(Gravity.CENTER_VERTICAL);
            toolbar.setPadding(dp(6), 0, dp(6), 0);
            toolbar.setBackgroundColor(TOOLBAR_BG);
            toolbar.setMinimumHeight(dp(56));

            TextView closeButton = toolbarButton("إغلاق");
            TextView backButton = toolbarButton("رجوع");
            inAppBrowserTitle = new TextView(this);
            inAppBrowserTitle.setText("متصفح Rumk الداخلي");
            inAppBrowserTitle.setTextColor(Color.WHITE);
            inAppBrowserTitle.setTextSize(14);
            inAppBrowserTitle.setSingleLine(true);
            inAppBrowserTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
            inAppBrowserTitle.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
            inAppBrowserTitle.setPadding(dp(8), 0, dp(8), 0);

            toolbar.addView(closeButton, new LinearLayout.LayoutParams(dp(62), dp(56)));
            toolbar.addView(backButton, new LinearLayout.LayoutParams(dp(62), dp(56)));
            toolbar.addView(inAppBrowserTitle, new LinearLayout.LayoutParams(0, dp(56), 1f));
            panel.addView(toolbar, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));

            inAppBrowser = new WebView(this);
            inAppBrowser.setBackgroundColor(DARK_BG);
            inAppBrowser.setOverScrollMode(View.OVER_SCROLL_NEVER);
            inAppBrowser.setVerticalScrollBarEnabled(false);
            inAppBrowser.setHorizontalScrollBarEnabled(false);
            android.webkit.WebSettings browserSettings = inAppBrowser.getSettings();
            browserSettings.setJavaScriptEnabled(true);
            browserSettings.setDomStorageEnabled(true);
            browserSettings.setDatabaseEnabled(true);
            browserSettings.setMediaPlaybackRequiresUserGesture(false);
            browserSettings.setLoadsImagesAutomatically(true);
            browserSettings.setJavaScriptCanOpenWindowsAutomatically(false);
            browserSettings.setSupportMultipleWindows(false);
            browserSettings.setAllowFileAccess(false);
            browserSettings.setAllowContentAccess(false);
            browserSettings.setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) browserSettings.setSafeBrowsingEnabled(true);
            CookieManager.getInstance().setAcceptCookie(true);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                CookieManager.getInstance().setAcceptThirdPartyCookies(inAppBrowser, true);
            }

            inAppBrowser.setWebChromeClient(new WebChromeClient() {
                @Override
                public void onReceivedTitle(WebView view, String title) {
                    if (inAppBrowserTitle != null && title != null && !title.trim().isEmpty()) {
                        inAppBrowserTitle.setText(title.trim());
                    }
                }
            });
            // Deliberately no JavascriptInterface on this WebView: provider pages are untrusted.
            inAppBrowser.setWebViewClient(new WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    Uri next = request.getUrl();
                    String nextScheme = next.getScheme() == null ? "" : next.getScheme().toLowerCase(Locale.ROOT);
                    if ("https".equals(nextScheme) || "http".equals(nextScheme)) return false;
                    Toast.makeText(MainActivity.this, "هذا النوع من الروابط لا يمكن فتحه داخل Rumk", Toast.LENGTH_SHORT).show();
                    return true;
                }

                @Override
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    Uri next = Uri.parse(url);
                    String nextScheme = next.getScheme() == null ? "" : next.getScheme().toLowerCase(Locale.ROOT);
                    if ("https".equals(nextScheme) || "http".equals(nextScheme)) return false;
                    Toast.makeText(MainActivity.this, "هذا النوع من الروابط لا يمكن فتحه داخل Rumk", Toast.LENGTH_SHORT).show();
                    return true;
                }
            });

            panel.addView(inAppBrowser, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
            inAppBrowserPanel = panel;
            rootLayout.addView(inAppBrowserPanel, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            closeButton.setOnClickListener(v -> closeInAppBrowser());
            backButton.setOnClickListener(v -> {
                if (inAppBrowser != null && inAppBrowser.canGoBack()) inAppBrowser.goBack();
                else closeInAppBrowser();
            });
        }

        inAppBrowserPanel.setVisibility(View.VISIBLE);
        inAppBrowserPanel.bringToFront();
        if (inAppBrowserTitle != null) inAppBrowserTitle.setText(uri.getHost());
        inAppBrowser.loadUrl(uri.toString());
    }

    private void closeInAppBrowser() {
        if (inAppBrowserPanel != null && rootLayout != null) {
            rootLayout.removeView(inAppBrowserPanel);
            inAppBrowserPanel = null;
        }
        if (inAppBrowser != null) {
            inAppBrowser.stopLoading();
            inAppBrowser.removeAllViews();
            inAppBrowser.destroy();
            inAppBrowser = null;
        }
        inAppBrowserTitle = null;
        if (webView != null) webView.requestFocus();
    }

    @Override
    public void onBackPressed() {
        if (inAppBrowserPanel != null) {
            if (inAppBrowser != null && inAppBrowser.canGoBack()) inAppBrowser.goBack();
            else closeInAppBrowser();
            return;
        }
        if (webView != null) {
            webView.evaluateJavascript("(function(){const d=document.querySelector('dialog[open]');if(d){d.close();return 'closed'};return 'back'})()", value -> {
                if ("\"back\"".equals(value)) finish();
            });
        } else {
            finish();
        }
    }

    private final class RumkBridge {
        @JavascriptInterface
        public void searchYouTubeRss(String query, String order, String callbackId) {
            if (query == null || query.length() > 180 || callbackId == null || !callbackId.matches("[0-9]{1,12}")) return;
            new Thread(() -> {
                String result;
                try {
                    result = fetchYoutubeSearchRss(query, "date".equals(order) ? "date" : "relevance");
                } catch (Exception e) {
                    result = "[]";
                }
                final String finalResult = result;
                runOnUiThread(() -> {
                    if (webView == null) return;
                    String js = "window.__rumkNativeResult(" + JSONObject.quote(callbackId) + "," + JSONObject.quote(finalResult) + ");";
                    webView.evaluateJavascript(js, null);
                });
            }, "rumk-youtube-rss").start();
        }

        // Kept with the old method name to remain compatible with earlier web assets;
        // behavior is now an in-app WebView, not an external Chrome launch.
        @JavascriptInterface
        public void openExternal(String rawUrl) {
            openInAppBrowser(rawUrl);
        }

        @JavascriptInterface
        public void openInApp(String rawUrl) {
            openInAppBrowser(rawUrl);
        }
    }

    private String fetchYoutubeSearchRss(String query, String order) throws Exception {
        String encoded = URLEncoder.encode(query, StandardCharsets.UTF_8.name());
        URL url = new URL("https://www.youtube.com/feeds/videos.xml?search_query=" + encoded + "&order=" + URLEncoder.encode(order, StandardCharsets.UTF_8.name()));
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(9000);
        connection.setReadTimeout(11000);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestProperty("Accept", "application/atom+xml, application/xml, text/xml, */*");
        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/126 Mobile Safari/537.36 RumkMK442/1.0");
        try {
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) return "[]";
            try (InputStream input = new BufferedInputStream(connection.getInputStream())) {
                return parseYoutubeXml(input);
            }
        } finally {
            connection.disconnect();
        }
    }

    private String parseYoutubeXml(InputStream input) throws Exception {
        XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
        factory.setNamespaceAware(true);
        XmlPullParser parser = factory.newPullParser();
        parser.setInput(input, "UTF-8");
        JSONArray results = new JSONArray();
        JSONObject current = null;
        StringBuilder text = new StringBuilder();
        boolean insideAuthor = false;
        int event = parser.getEventType();
        while (event != XmlPullParser.END_DOCUMENT && results.length() < 25) {
            if (event == XmlPullParser.START_TAG) {
                String tag = parser.getName();
                text.setLength(0);
                if ("entry".equals(tag)) {
                    current = new JSONObject();
                    insideAuthor = false;
                } else if (current != null && "author".equals(tag)) {
                    insideAuthor = true;
                }
            } else if (event == XmlPullParser.TEXT || event == XmlPullParser.CDSECT) {
                text.append(parser.getText());
            } else if (event == XmlPullParser.END_TAG) {
                String tag = parser.getName();
                String value = text.toString().trim();
                if (current != null && !value.isEmpty()) {
                    if ("videoId".equals(tag) && !current.has("id")) current.put("id", value);
                    else if ("title".equals(tag) && !current.has("title")) current.put("title", value);
                    else if ("name".equals(tag) && insideAuthor && !current.has("author")) current.put("author", value);
                    else if ("published".equals(tag) && !current.has("published")) current.put("published", value);
                }
                if ("author".equals(tag)) insideAuthor = false;
                if ("entry".equals(tag) && current != null) {
                    String id = current.optString("id", "");
                    if (!id.isEmpty()) {
                        current.put("url", "https://www.youtube.com/watch?v=" + id);
                        current.put("thumbnail", "https://i.ytimg.com/vi/" + id + "/hqdefault.jpg");
                        current.put("description", "");
                        results.put(current);
                    }
                    current = null;
                }
                text.setLength(0);
            }
            event = parser.next();
        }
        return results.toString();
    }

    @Override
    protected void onDestroy() {
        closeInAppBrowser();
        if (webView != null) {
            webView.removeJavascriptInterface("RumkNative");
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
        rootLayout = null;
        super.onDestroy();
    }
}
